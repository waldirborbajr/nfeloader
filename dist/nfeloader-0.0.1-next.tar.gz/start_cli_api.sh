#!/usr/bin/env sh

/app/nfeloader
/app/nfeloader-api

