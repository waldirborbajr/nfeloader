package entity

type NFeConfig struct {
	MailServer       string
	MailUsr          string
	MailPwd          string
	DatabaseHost     string
	DatabaseUsr      string
	DatabasePwd      string
	DatabaseDbName   string
	TelegramChatID   string
	TelegramBotToken string
	Schedule         string
}
