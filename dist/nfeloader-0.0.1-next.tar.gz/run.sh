#!/bin/sh
cd /app
./nfeloader

