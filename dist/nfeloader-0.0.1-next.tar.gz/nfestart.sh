#!/use/bin/env sh

./nfeloader

./nfeloader-api
