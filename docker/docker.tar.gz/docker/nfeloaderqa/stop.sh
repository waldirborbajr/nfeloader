#!/bin/sh

docker rm -f nfeloaderqa

