#!/usr/bin/env sh

# login 
# docker login ghcr.io
# curl -v -u waldirborbajr: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 https://ghcr.io/v2/

# Stop and remove container
docker rm -f nfeloaderqa

VERSION="0.4.3"

# Fetch for update
docker pull ghcr.io/waldirborbajr/nfeloader:${VERSION}

# Start
docker run -d -i -t -p 9693:9693 --rm \
-e MAIL_SERVER="mail.omniinformatica.com.br:993" \
-e MAIL_USR="waldir@omniinformatica.com.br" \
-e MAIL_PWD="Rdw6qh5KQ1GLbVKscBtXawmIpq" \
-e DATABASE_HOST="192.168.0.4:3306" \
-e DATABASE_USR="root" \
-e DATABASE_PWD="@senha" \
-e DATABASE_NAME="ICMS_NATAL_DEV" \
-e TIME_SCHEDULE="1m" \
-e CONTAINER="true" \
--name nfeloaderqa ghcr.io/waldirborbajr/nfeloader:${VERSION} \
sh

# Show me the log
docker logs -f nfeloaderqa
