#!/bin/sh

docker exec -it nfeloaderqa /bin/sh

