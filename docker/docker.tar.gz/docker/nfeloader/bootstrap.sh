#!/usr/bin/env sh

# login 
# docker login ghcr.io
# curl -v -u waldirborbajr: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 https://ghcr.io/v2/

VERSION="0.4.4"

# Stop and remove container
docker rm -f nfeloader

# Fetch for update
docker pull ghcr.io/waldirborbajr/nfeloader:${VERSION}

# Start
docker run -d -i -t -p 9396:9396 \
-e MAIL_SERVER="mail.omniinformatica.com.br:993" \
-e MAIL_USR="xmlapple@omniinformatica.com.br" \
-e MAIL_PWD="#Senha_123_Mudar*" \
-e DATABASE_HOST="192.168.0.4:3306" \
-e DATABASE_USR="root" \
-e DATABASE_PWD="@senha" \
-e DATABASE_NAME="ICMS_NATAL" \
-e TIME_SCHEDULE="2m" \
-e CONTAINER="true" \
--restart unless-stopped \
--name nfeloader ghcr.io/waldirborbajr/nfeloader:${VERSION} \
sh

# Show me the log
# docker logs -f nfeloader
