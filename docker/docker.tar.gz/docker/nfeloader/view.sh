#!/bin/sh

docker exec -it nfeloader /bin/sh

